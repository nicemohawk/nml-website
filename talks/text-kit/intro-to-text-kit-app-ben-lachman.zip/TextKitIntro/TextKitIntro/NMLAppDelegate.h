//
//  NMLAppDelegate.h
//  TextKitIntro
//
//  Created by Ben Lachman on 2/19/14.
//  Copyright (c) 2014 Ben Lachman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NMLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
