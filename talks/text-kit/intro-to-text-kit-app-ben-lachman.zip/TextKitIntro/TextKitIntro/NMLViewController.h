//
//  NMLViewController.h
//  TextKitIntro
//
//  Created by Ben Lachman on 2/19/14.
//  Copyright (c) 2014 Ben Lachman. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NMLViewController : UIViewController

@property (nonatomic, weak) UITextView *firstColumnTextView;
@property (nonatomic, weak) UITextView *secondColumnTextView;

@end
